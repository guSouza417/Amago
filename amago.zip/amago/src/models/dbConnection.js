var sql = require("mysql")

function connection(){
	return sql.createConnection({
		host: "localhost",
		user: "root",
		password: "az12345678",
		database: "amago",
		insecureAuth: "true",
		multipleStatements: "true"
	})
}

module.exports = function(){
	return connection
}