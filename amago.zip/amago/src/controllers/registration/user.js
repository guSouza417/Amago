const express = require("express")
const app = require("../../../server")
const sendEmail = require("./nodemailer")

var code = null

var objUser = {
	name: null,
	email: null,
	password: null//,
	//codeTypedByUser: null
}



exports.renderRegistration = (req, res) => {
	res.render("cadastroUsuario")
}

exports.thisEmailAlreadyExist = (req, res, next) => {
	objUser.name = req.body.name
	objUser.email = req.body.email
	objUser.password = req.body.password

	console.log("\n\nNome do usuário: " + objUser.name + "\n")
	console.log("\n\nEmail do usuário: " + objUser.email + "\n")
	console.log("\n\nSenha do usuário: " + objUser.password + "\n")

	var connection = app.src.models.dbConnection()
	var user = new app.src.models.user(connection)

	user.thisUserAlreadyExist(objUser, function(error, success){
		if(error){
			console.log("Erro na verificação de email: " + error)
		}
		else{
			var contagem = success[0]['email']

			if(contagem == 0){
				console.log("\n\nVerificou se o e-mail existia ou não corretamente\n\n")
				next()
			}
			else{
				console.log("\n\nElse-Sucesso: " + JSON.stringify(success) + "\n\n")
				console.log("\nJá existe um usuário cadastrado com essa conta")
				//res.redirect("cadastroUsuario")
			}
		}
	})
}


exports.generateCode = (req, res, next) => {
	try{
		var generateCode = []

		for(let i = 0; i != 6; i++){
			let num = Math.floor(Math.random() * 10)
			generateCode.push(num)
		}

		code = generateCode.join('')
		console.log("Código: " + code)
		next()
	}
	catch(error){
		console.log("Erro no geramento do número aleatório: " + error)
	}
}


exports.sendConfirmationEmail = (req, res, next) => {
	try{
		sendEmail(code, objUser).catch(console.error)
		next()
	}
	catch(error){
		console.log("Erro no envio do e-mail de confirmação: " + error)
	}
}


exports.verificationCode = (req, res/*, next*/) => {
	try{
		res.render("verificationCode")

		objUser.codeTypedByUser = req.body.codeTypedByUser
		console.log("Valor do objeto: " + objUser.codeTypedByUser)

		if(code == objUser.codeTypedByUser){
			console.log("O código digitado pelo usuário é igual o recebido no e-mail")
		}
		else{
			console.log("O código digitado é inválido!")
		}
	}
	catch(error){
		console.log("\n\nErro na validação do código digitado pelo usuário: " + error + "\n\n")
	}
}


exports.insert = (req, res) => {
	//var data = req.body
	var connection = app.src.models.dbConnection()
	var user = new app.src.models.user(connection)

	user.save(data, function(error, success){
		if(error){
			console.log(error)
		}
	})

	res.render("consultarUsuario", {"data": data})
}