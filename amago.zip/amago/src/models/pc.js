/*
//CONECTA O BANCO DE DADOS AO USUÁRIO
	function pc(dbConection){
		this._conection = dbConection
	}



//INSERE USUÁRIOS
	pc.prototype.save = function(){
		this._conection.query("INSERT INTO ")
	}

//CONSULTA USUÁRIOS
	pc.prototype.select.query("")


//ALTERA USUÁRIOS

//DELETA USUÁRIOS

module.exports = function(){
	return pc
}*/