const express = require("express")
const app = express()

const load = require("express-load")
load("./src/models").into(app)

const path = require("path")
var session = require("express-session")

app.set("views", path.resolve(__dirname, "src", "views"))
app.set("view engine", "ejs")

app.use(express.static(path.resolve(__dirname, "public")))

app.use(express.urlencoded({extended: false}))
app.use(express.json())

app.use(session({
	secret: "asdfasdaghdsf",
	resave: false,
	saveUninitialized: true,
	cookie: {secure: true}
}))

app.listen(8080, () => {console.log("Servidor criado com sucesso!")})

module.exports = app

const routes = require("./routes")
app.use(routes)