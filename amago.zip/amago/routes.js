const express = require("express")
const route = express.Router()

//HOME
	const home = require("./src/controllers/home")
		route.get("/home", home.render)



//CADASTRO DO USUÁRIO
	const user = require("./src/controllers/registration/user")
		//GET
			route.get("/cadastroUsuario", user.renderRegistration)
		//POST
			route.post("/inserirUsuario", user.thisEmailAlreadyExist,
				                          user.generateCode,
				                          user.sendConfirmationEmail,
				                          user.verificationCode/*,
				                          user.insert*/)

//LOGIN DO USUÁRIO
	const login = require("./src/controllers/login")
		//GET
			route.get("/login", login.renderLogin)
		//POST
			route.post("/validarLogin", login.loginVerification)

//404
	route.use((req, res) => res.status(404).render("404"))

module.exports = route