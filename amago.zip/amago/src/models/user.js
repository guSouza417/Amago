//CONECTA O BANCO DE DADOS AO USUÁRIO
	function user(connection){
		this._connection = connection
	}

//INSERE USUÁRIOS
	user.prototype.save = function(data, callback){
		this._connection.query("INSERT INTO usuario SET ?", data, callback)
	}

//VERIFICA SE A CONTA DO USUÁRIO JÁ EXISTE DURANTE O CADASTRO
	user.prototype.thisUserAlreadyExist = function(objUser, callback){
		this._connection.query("SELECT COUNT(email) AS email FROM usuario WHERE email = ?", objUser.email, callback)
	}


//ALTERA USUÁRIOS

//DELETA USUÁRIOS

module.exports = function(){
	return user
}