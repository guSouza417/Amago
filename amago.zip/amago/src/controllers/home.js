exports.render = (req, res) => {
	res.render("home")
}