DROP DATABASE IF EXISTS amago;

CREATE DATABASE amago;
USE amago;



CREATE TABLE perfilUsuario -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	tipoPerfil VARCHAR (16) NOT NULL
);

INSERT INTO perfilUsuario (tipoPerfil) VALUES
("usuario"),
("pontos de coleta");



CREATE TABLE fotoUsuario -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	foto VARCHAR(50) NOT NULL
);



CREATE TABLE fotoPc -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	foto VARCHAR(50) NOT NULL
);



CREATE TABLE tipoLixo -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	tipoLixo VARCHAR (10) NOT NULL
);

INSERT INTO tipoLixo (tipoLixo) VALUES
("organico"),
("domestico"),
("comercial"),
("publico"),
("industrial"),
("hospitalar"),
("verde"),
("eletronico"),
("radioativo");



CREATE TABLE tiposInstituicoesPc -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	tiposInstituicoesPc VARCHAR (100) NOT NULL
);

-- colocar os insert



CREATE TABLE usuario -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR (60) NOT NULL,
	email VARCHAR (50) NOT NULL,
	password VARCHAR (15) NOT NULL,

	id_perfil INT,
	id_fotoUsuario INT,
	id_tipoLixo INT,

	CONSTRAINT fk_perfil_usuario FOREIGN KEY (id_perfil) REFERENCES perfilUsuario (id),
	CONSTRAINT fk_fotoUsuario_usuario FOREIGN KEY (id_fotoUsuario) REFERENCES fotoUsuario (id),
	CONSTRAINT fk_tipoLixo_usuario FOREIGN KEY (id_tipoLixo) REFERENCES tipoLixo (id)
);



CREATE TABLE pc -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR (60) NOT NULL,
	email VARCHAR (50) NOT NULL,
	senha VARCHAR (15) NOT NULL,

	id_perfil INT NOT NULL,
	id_tipoLixo INT NOT NULL,
	id_fotoPc INT NOT NULL,
	id_tipoInstituicoesPc INT NOT NULL,

	CONSTRAINT fk_perfil_pc FOREIGN KEY (id_perfil) REFERENCES perfilUsuario (id),
	CONSTRAINT fk_tipoLixo_pc FOREIGN KEY (id_tipoLixo) REFERENCES tipoLixo (id),
	CONSTRAINT fk_fotoPc_pc FOREIGN KEY (id_fotoPc) REFERENCES fotoPc (id),
	CONSTRAINT fk_tipoInstituicoes_pc FOREIGN KEY (id_tipoInstituicoesPc) REFERENCES tiposInstituicoesPc (id)
);



CREATE TABLE avaliacoes -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	numeroEstrelas INT NOT NULL,

	id_usuario INT NOT NULL,
	id_pc INT NOT NULL,

	CONSTRAINT fk_usuario_avaliacoes FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_pc_avaliacoes FOREIGN KEY (id_pc) REFERENCES pc (id)
);



-- tabelas para os comentários

CREATE TABLE comentariosPc -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	comentario TEXT NOT NULL,

	id_usuario INT NOT NULL,
	id_pc INT NOT NULL,

	CONSTRAINT fk_usuario_comentariosPc FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_pc_comentariosPc FOREIGN KEY (id_pc) REFERENCES pc (id)
);



CREATE TABLE comentariosPc2 -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	comentario TEXT NOT NULL,

	id_usuario INT NOT NULL,
	id_pc INT NOT NULL,
	id_comentariosPc INT NOT NULL,

	CONSTRAINT fk_usuario_comentariosPc2 FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_pc_comentariosPc2 FOREIGN KEY (id_pc) REFERENCES pc (id),
	CONSTRAINT fk_comentariosPc_comentariosPc2 FOREIGN KEY (id_comentariosPc) REFERENCES comentariosPc (id)
);



CREATE TABLE comentariosMaterias -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	comentario TEXT NOT NULL,

	id_usuario INT NOT NULL,

	CONSTRAINT fk_usuario_comentariosMaterias FOREIGN KEY (id_usuario) REFERENCES usuario (id)
);



CREATE TABLE comentariosMaterias2 -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	comentario TEXT NOT NULL,

	id_usuario INT NOT NULL,
	id_comentariosMaterias INT NOT NULL,

	CONSTRAINT fk_usuario_comentariosMaterias2 FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_comentariosMaterias_comentariosMaterias2 FOREIGN KEY (id_comentariosMaterias) REFERENCES comentariosMaterias (id)
);



-- midias

CREATE TABLE midiaPc -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	imagem VARCHAR(50) NOT NULL,

	id_usuario INT NOT NULL,
	id_pc INT NOT NULL,
	id_comentariosPc INT NOT NULL,

	CONSTRAINT fk_usuario_MidiaPc FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_pc_midiaPc FOREIGN KEY (id_pc) REFERENCES pc (id),
	CONSTRAINT fk_comentariosPc_midiaPc FOREIGN KEY (id_comentariosPc) REFERENCES comentariosPc (id)
);



CREATE TABLE midiaPc2 -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	imagem VARCHAR(50) NOT NULL,

	id_usuario INT NOT NULL,
	id_pc INT NOT NULL,
	id_comentariosPc2 INT NOT NULL,
	id_midiaPc INT NOT NULL,

	CONSTRAINT fk_usuario_midiaPc2 FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_pc_midiaPc2 FOREIGN KEY (id_pc) REFERENCES pc (id),
	CONSTRAINT fk_comentariosPc2_midiaPc2 FOREIGN KEY (id_comentariosPc2) REFERENCES comentariosPc2 (id),
	CONSTRAINT fk_midiaPc_midiaPc2 FOREIGN KEY (id_midiaPc) REFERENCES midiaPc (id)
);



CREATE TABLE midiaMaterias -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	imagem VARCHAR(50) NOT NULL,

	id_usuario INT NOT NULL,
	id_comentariosMaterias INT NOT NULL,

	CONSTRAINT fk_usuarioMidiaMaterias FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_comentariosMaterias_midiaMaterias FOREIGN KEY (id_comentariosMaterias) REFERENCES comentariosMaterias (id)
);



CREATE TABLE midiaMaterias2 -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	imagem VARCHAR(50) NOT NULL,

	id_usuario INT NOT NULL,
	id_comentariosMaterias2 INT NOT NULL,
	id_midiaMaterias INT NOT NULL,

	CONSTRAINT fk_usuario_MidiaMaterias2 FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_comentariosMaterias2_midiaMaterias2 FOREIGN KEY (id_comentariosMaterias2) REFERENCES comentariosMaterias2 (id), 
	CONSTRAINT fk_midiaMaterias_midiaMaterias2 FOREIGN KEY (id_midiaMaterias) REFERENCES midiaMaterias (id)
);



-- curtidas

CREATE TABLE curtidasPc -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	quantidade INT NOT NULL,

	id_usuario INT NOT NULL,
	id_pc INT NOT NULL,
	id_comentariosPc INT NOT NULL,

	CONSTRAINT fk_usuario_curtidasPc FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_pc_curtidasPc FOREIGN KEY (id_pc) REFERENCES pc (id),
	CONSTRAINT fk_comentariosPc_curtidasPc FOREIGN KEY (id_comentariosPc) REFERENCES comentariosPc (id)
);



CREATE TABLE curtidasPc2 -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	quantidade INT NOT NULL,

	id_usuario INT NOT NULL,
	id_pc INT NOT NULL,
	id_comentariosPc2 INT NOT NULL,

	CONSTRAINT fk_usuario_curtidasPc2 FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_pc_curtidasPc2 FOREIGN KEY (id_pc) REFERENCES pc (id),
	CONSTRAINT fk_comentariosPc2_curtidasPc2 FOREIGN KEY (id_comentariosPc2) REFERENCES comentariosPc2 (id)
);



CREATE TABLE curtidasMaterias -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	quantidade INT NOT NULL,

	id_usuario INT NOT NULL,
	id_comentariosMaterias INT NOT NULL,

	CONSTRAINT fk_usuario_curtidasMaterias FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_comentariosMaterias_curtidasMaterias FOREIGN KEY (id_comentariosMaterias) REFERENCES comentariosMaterias (id)
);



CREATE TABLE curtidasMaterias2 -- já foi
(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	quantidade INT NOT NULL,

	id_usuario INT NOT NULL,
	id_comentariosMaterias2 INT NOT NULL,

	CONSTRAINT fk_usuario_curtidasMaterias2 FOREIGN KEY (id_usuario) REFERENCES usuario (id),
	CONSTRAINT fk_comentariosMaterias2_curtidasMaterias2 FOREIGN KEY (id_comentariosMaterias2) REFERENCES comentariosMaterias2 (id)
);