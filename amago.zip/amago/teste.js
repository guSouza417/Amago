function a(){
	var generateCode = []

	for(let i = 0; i != 6; i++){
		let num = Math.floor(Math.random() * 10)
		generateCode.push(num)
	}

	return generateCode.join('')
}