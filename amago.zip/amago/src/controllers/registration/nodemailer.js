"use strict"

const nodemailer = require("nodemailer")

async function sendEmail(code, objUser){
	let testAccount = await nodemailer.createTestAccount();

	let transporter = nodemailer.createTransport({
		host: "smtp.gmail.com",
		port: 587,
		secure: false,
		auth: {
			user: "ecoamagoofficial@gmail.com",
			pass: "vjbgyxtgxxnukkkb"
		}
	})

	let info = await transporter.sendMail({
		from: "Âmago Official <ecoamagoofficial@gmail.com>",
		to: "guilherme234fer@gmail.com",
		//to: objUser.email,

		subject: "E-mail de confirmação de cadastro",
		text: "Olá " + objUser.name + ". Seu código é " + code
	})

	console.log("Message sent: %s", info.messageId)
 	console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info))
}

module.exports = sendEmail