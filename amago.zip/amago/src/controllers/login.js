const express = require("express")
const app = require("../../server")

exports.renderLogin = (req, res) => {
	res.render("login")
}

exports.loginVerification = (req, res) => {
	console.log("Solicitação recebida")
}